import os
import PIL
import numpy as np
import torch
import torch.nn.functional as F
import torchvision.models as models
from numpy.ma.core import shape
# from scipy.special import dtype
from torchvision.utils import make_grid, save_image
import matplotlib.pyplot as plt
import cv2
from utils_test import visualize_cam, Normalize
from grad_cam_final import GradCAM, GradCAMpp

img_dir = 'C:\\Users\\rajes\\Downloads\\DataSet\\Small_pascal_VOC\\JPEGImages\\New'
# img_name = 'collies.JPG'
# img_name = 'multiple_dogs.jpg'
# img_name = 'snake.JPEG'
img_name = '2009_002993.jpg'
img_path = os.path.join(img_dir, img_name)

### Prepare Segmentation Image for IOU
segmentation_image_path = "C:\\Users\\rajes\\Downloads\\DataSet\\VOCtrainval_11-May-2012\\VOCdevkit\\VOC2012\\SegmentationClass\\2009_002993.png"
segmentation_image = PIL.Image.open(segmentation_image_path)
new_dimension  = (224,224)
resized_segmentation = segmentation_image.resize(new_dimension)


# plt.figure(figsize=(8, 8))
# plt.imshow(img_path)

pil_img = PIL.Image.open(img_path)
# pil_img.show()

def iou_calculate_from_mask(segmented_image, heatmap_mask):
    threshold = 0.5
    # print(type(heatmap_mask))
    # print(type(segmented_image))
    heatmap_mask_np = np.array(heatmap_mask)
    binary_mask = (heatmap_mask_np > threshold).astype(np.uint8)
    # Save the binary mask as an image
    mask_path = "C:\\Users\\rajes\\Downloads\\DataSet\\Small_pascal_VOC\\Output\\gradcam_binary_mask_2009_002993.png"
    cv2.imwrite(mask_path, binary_mask * 255)
    print(f"Binary mask saved at: {mask_path}")

    # Calculate IoU
    intersection = np.logical_and(binary_mask, segmented_image).sum()
    union = np.logical_or(binary_mask, segmented_image).sum()
    iou = intersection / union if union > 0 else 0
    return iou


normalizer = Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
torch_img = torch.from_numpy(np.asarray(pil_img)).permute(2, 0, 1).unsqueeze(0).float().div(255)
torch_img = F.upsample(torch_img, size=(224, 224), mode='bilinear', align_corners=False)
normed_torch_img = normalizer(torch_img)


########### Model download ###########
alexnet = models.alexnet(pretrained=True)
alexnet.eval()
 # alexnet.cuda());

vgg = models.vgg16(pretrained=True)
vgg.eval()
 # vgg.cuda());

resnet = models.resnet101(pretrained=True)
resnet.eval()
 # resnet.cuda());

densenet = models.densenet161(pretrained=True)
densenet.eval()
 # densenet.cuda());

squeezenet = models.squeezenet1_1(pretrained=True)
squeezenet.eval()
 # squeezenet.cuda());


cam_dict = dict()

alexnet_model_dict = dict(type='alexnet', arch=alexnet, layer_name='features_11', input_size=(224, 224))
alexnet_gradcam = GradCAM(alexnet_model_dict, True)
alexnet_gradcampp = GradCAMpp(alexnet_model_dict, True)
cam_dict['alexnet'] = [alexnet_gradcam, alexnet_gradcampp]

vgg_model_dict = dict(type='vgg', arch=vgg, layer_name='features_29', input_size=(224, 224))
vgg_gradcam = GradCAM(vgg_model_dict, True)
vgg_gradcampp = GradCAMpp(vgg_model_dict, True)
cam_dict['vgg'] = [vgg_gradcam, vgg_gradcampp]

resnet_model_dict = dict(type='resnet', arch=resnet, layer_name='layer4', input_size=(224, 224))
resnet_gradcam = GradCAM(resnet_model_dict, True)
resnet_gradcampp = GradCAMpp(resnet_model_dict, True)
cam_dict['resnet'] = [resnet_gradcam, resnet_gradcampp]

densenet_model_dict = dict(type='densenet', arch=densenet, layer_name='features_norm5', input_size=(224, 224))
densenet_gradcam = GradCAM(densenet_model_dict, True)
densenet_gradcampp = GradCAMpp(densenet_model_dict, True)
cam_dict['densenet'] = [densenet_gradcam, densenet_gradcampp]

squeezenet_model_dict = dict(type='squeezenet', arch=squeezenet, layer_name='features_12_expand3x3_activation', input_size=(224, 224))
squeezenet_gradcam = GradCAM(squeezenet_model_dict, True)
squeezenet_gradcampp = GradCAMpp(squeezenet_model_dict, True)
cam_dict['squeezenet'] = [squeezenet_gradcam, squeezenet_gradcampp]

images = []
iou_list_gradcam = list()
iou_list_gradcampp = list()
i=0
for gradcam, gradcam_pp in cam_dict.values():
    print(i)
    # print(cam_dict.keys(i))
    # print(cam_dict.values(i))
    mask, _ = gradcam(normed_torch_img)
    heatmap, result = visualize_cam(mask, torch_img)

    mask_pp, _ = gradcam_pp(normed_torch_img)
    heatmap_pp, result_pp = visualize_cam(mask_pp, torch_img)

    # images.append(torch.stack([torch_img.squeeze().cpu(), heatmap, heatmap_pp, result, result_pp], 0))
    iou_calculated_gradcam = iou_calculate_from_mask(resized_segmentation, mask)
    iou_calculated_gradcampp = iou_calculate_from_mask(resized_segmentation, mask_pp)
    iou_list_gradcam.append(iou_calculated_gradcam)
    iou_list_gradcampp.append(iou_calculated_gradcampp)
    # images = make_grid(torch.cat(images, 0), nrow=5)
    i=i+1

# print(heatmap)
# output_dir = 'C:\\Users\\rajes\\Downloads\\DataSet\\Small_pascal_VOC\\Output'
# os.makedirs(output_dir, exist_ok=True)
# output_name = img_name
# output_path = os.path.join(output_dir, output_name)

# save_image(images, output_path)
# PIL.Image.open(output_path)



# print(type(mask))
# mask_array = np.array(mask)
# mask_array = cv2.resize(mask,(224,224))
# image_mask = PIL.Image.fromarray(mask_array)
# print(shape(mask))
# print(shape(mask_array))

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.title("resized input")
plt.imshow(resized_segmentation)

plt.subplot(1, 2, 2)
plt.title("Mask output")
# plt.imshow(image_mask)

print(iou_list_gradcam)
print(iou_list_gradcampp)
# iou_calculated_gradcam = iou_calculate_from_mask(resized_segmentation,mask)
# print(f"IoU between Grad-CAM mask and ground truth: {iou_calculated_gradcam:.4f}")
# plt.show()
print(cam_dict.keys)
print(cam_dict.values)